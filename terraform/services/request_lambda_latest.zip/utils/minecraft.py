from mcstatus import JavaServer
from typing import Dict, Any
from .logger import setup_logging

class MinecraftServer:
    def __init__(self, ip: str, port: str):
        self.logger = setup_logging()
        self.ip = ip
        self.port = port
        self.server_address = f"{self.ip}:{self.port}"
        self.java_server = JavaServer.lookup(self.server_address)

    def check(self) -> Dict[str, Any]:
        """
        Checks the status of the Minecraft server.
        """
        try:
            status = self.java_server.status()
            return {
                'online': self.java_server.ping() is not None,
                'players_online': status.players.online,
                'version': status.version.name
            }
        except Exception as e:
            self.logger.warning(f"Warning: Could not check the Minecraft server. Maybe its offline? Error: '{str(e)}'.")
            return {
                'online': False,
                'players_online': 0,
                'version': 'unknown'
            }
    
    def get_server_port(self):
        return self.port
